# QuarticMaxwell Lean source supplement

This archive is independently usable without access to the authors' repository.
It preserves the monorepo-relative layout needed by the unchanged verifiers.
The byte-identical original dated PDF/TXT identifies the target manuscript; it
is historical source material, not a second current article or new review.

## Exact checked scope

Read `papers/quartic-maxwell/formalization/verification/report.json` and the included current claim-coverage ledger before making a
verification claim. The package gate requires all current paper proof modules,
their exact hashes, current required public roots/type guards, successful
compilation/type/axiom census, and successful fresh replay. A theorem count does
not certify every original sentence, empirical table, novelty claim, or human
peer review. Expected-failure controls are separate from successful proofs.
`leanchecker --fresh` replays Lean's own kernel implementation; it is not an
independently implemented kernel. The allowed standard axioms are `propext`,
`Classical.choice`, and `Quot.sound`.

## Integrity and contents

Before creating build caches, extract to a new empty directory and run:

```text
python verify_supplement.py
```

`MANIFEST.json` hashes every payload file and classifies its role. `SHA256SUMS`
also hashes the manifest; it excludes itself to avoid a circular hash. The
manifest records the exact source import graph and final report/source coverage.
The preserved dependency source trees are complete active `OQ7` and
`PrescribedExtinction` trees, with both aggregates and their original pins.

## Restore and build

Use Python 3.10+, Git, and the exact Lean toolchain `leanprover/lean4:v4.34.1`
(Lean commit `5045d0056413266e57c625dcd7c365b10e377c52`). Install that toolchain using elan or the
official Lean release, then activate it. Mathlib is pinned to
`d13f23b723b8a846827a245b89c10fc7d3f11612`; all nine dependency revisions are in the included
`papers/prescribed-extinction/formalization/lake-manifest.json`.

From the extracted archive root:

```text
python restore_pinned_dependencies.py
cd papers/prescribed-extinction/formalization
lake exe cache get
lake build OQ7 PrescribedExtinction
```

The bootstrap clones only the exact manifest commits, checks Git revisions and
tracked-source cleanliness, refuses incompatible existing checkouts, and leaves
the manifest unchanged. Network access is needed for dependency source and the
optional Mathlib build cache. No private repository is needed. Do not run
`lake update` or change a pin. A clean source build can replace cache retrieval.

From `papers/quartic-maxwell/formalization`, run the unchanged current verifier:

```text
python verify.py --lean-bin /absolute/path/to/pinned/bin --fresh-kernel
```

Supply the absolute directory containing pinned `lean`/`leanchecker` (or their
Windows `.exe` names). This rebuilds the current proof project, audits the
reported roots and axioms, and freshly replays the aggregate closure. Preserve
the included final records; generalized reproduction writes a new directory.
The quartic verifier writes its current `verification/report.json` and logs,
so retain the original archive separately before rerunning it.

## Expected-failure controls

From the same paper formalization directory:

```text
python verify_negative_controls.py --project . --scratch ../../../.local/quartic-controls --lean-bin /absolute/path/to/pinned/bin
python verify_type_controls.py --project .
```

Both control runners accept the same explicit pinned toolchain bin directory.
The generalized control runner also requires the single included historical
`verification/checkpoint-main-claims/types-and-axioms.log` fixture. It is
labelled a negative-control fixture in the manifest, not a current success
report. No historical proof snapshots or old report duplicates are included.

## Deliberate exclusions

No TeX/LaTeX/BibTeX, manuscript build inputs, compiled Lean artifacts, dependency
caches, compiler binaries, downloaded tools, credentials, Git metadata,
historical source snapshots, or unrelated papers are included. Dependencies are
restored by their public exact commits. Report references to excluded article
TeX or generated `.olean` hashes are provenance metadata; those files are not
part of this source-only supplement. The article source is submitted separately.

arXiv's ancillary-file instructions permit supporting program code in `anc/`
and exclude TeX from that directory:
https://info.arxiv.org/help/ancillary_files.html
