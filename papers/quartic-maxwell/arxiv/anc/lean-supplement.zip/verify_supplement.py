"""Check every file hash and ensure no unlisted supplement content is present."""
from pathlib import Path,PurePosixPath
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
expected={row['path']:row for row in manifest['files']}
for name,row in expected.items():
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts or '\\' in name or any(':' in s for s in p.parts):
  raise SystemExit('Unsafe manifest path')
 target=root.joinpath(*p.parts)
 if target.is_symlink() or not target.is_file(): raise SystemExit('Missing/linked file: '+name)
 data=target.read_bytes()
 if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
  raise SystemExit('Hash mismatch: '+name)
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
if actual!=set(expected)|{'MANIFEST.json','SHA256SUMS'}:
 raise SystemExit('Unlisted/missing content; run before creating .lake/build caches')
lines=(root/'SHA256SUMS').read_text(encoding='utf-8').splitlines()
for line in lines:
 digest,name=line.split('  ',1)
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise SystemExit('SHA256SUMS mismatch: '+name)
if {line.split('  ',1)[1] for line in lines} != set(expected)|{'MANIFEST.json'}:
 raise SystemExit('SHA256SUMS inventory differs')
print('All '+str(len(expected))+' payload hashes, manifest hash and archive inventory passed.')
