"""Restore exact dependency commits from the included immutable Lake manifest.
Requires Python 3.10+, Git, the pinned Lean toolchain, and network access.
No lake update, dependency pin rewrite, compiler download or binary is bundled.
"""
from pathlib import Path
import argparse, hashlib, json, re, subprocess
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'papers/prescribed-extinction/formalization'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--check-only',action='store_true')
args=parser.parse_args()
manifest=BASE/'lake-manifest.json'
before=hashlib.sha256(manifest.read_bytes()).hexdigest()
pins=json.loads(manifest.read_text(encoding='utf-8-sig'))
for package in pins['packages']:
 name,rev,url=package['name'],package['rev'],package['url']
 if not re.fullmatch(r'[A-Za-z0-9_-]+',name) or not re.fullmatch(r'[0-9a-f]{40}',rev):
  raise SystemExit('Unsafe dependency name/revision')
 if not re.fullmatch(r'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:\.git)?',url):
  raise SystemExit('Unexpected dependency source URL')
 target=BASE/'.lake/packages'/name
 if not target.exists():
  if args.check_only: raise SystemExit('Missing dependency: '+name)
  target.parent.mkdir(parents=True,exist_ok=True)
  target.mkdir()
  subprocess.run(['git','-C',str(target),'init'],check=True)
  subprocess.run(['git','-C',str(target),'remote','add','origin',url],check=True)
  subprocess.run(['git','-C',str(target),'fetch','--depth','1','origin',rev],check=True)
  subprocess.run(['git','-C',str(target),'checkout','--detach',rev],check=True)
 actual=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()
 if actual!=rev: raise SystemExit('Refusing existing dependency at a different commit: '+name)
 if subprocess.run(['git','-C',str(target),'diff','--quiet','HEAD','--']).returncode:
  raise SystemExit('Dependency has modified tracked source: '+name)
 if subprocess.check_output(['git','-C',str(target),'status','--porcelain','--untracked-files=no'],text=True).strip():
  raise SystemExit('Dependency checkout/index is not clean: '+name)
 print(name+' '+actual)
if hashlib.sha256(manifest.read_bytes()).hexdigest()!=before:
 raise SystemExit('Lake manifest changed during restore')
print('All exact dependency revisions restored and checked. Next run lake exe cache get; lake build OQ7 PrescribedExtinction in '+str(BASE))
