/-
Copyright (c) 2024 Mario Carneiro. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Carneiro, Edward van de Meent
-/
module

public meta import Lean.Elab.Syntax
public meta import Lean.DocString
public meta import Batteries.Util.LibraryNote

public meta section

/-!

# The `#help` command

The `#help` command can be used to list all definitions in a variety of extensible aspects of lean.

* `#help option` lists options (used in `set_option myOption`)
* `#help attr` lists attributes (used in `@[myAttr] def foo := ...`)
* `#help cats` lists syntax categories (like `term`, `tactic`, `stx` etc)
* `#help cat C` lists elements of syntax category C
  * `#help term`, `#help tactic`, `#help conv`, `#help command`
    are shorthand for `#help cat term` etc.
  * `#help cat+ C` also shows `elab` and `macro` definitions associated to the syntaxes
* `#help note "some note"` lists library notes for which "some note" is a prefix of the label

Most forms take an optional identifier to narrow the search; for example `#help option pp` shows
only `pp.*` options. However, `#help cat` makes the identifier mandatory, while `#help note` takes
a mandatory string literal, rather than an identifier.

-/

namespace Batteries.Tactic
open Lean Meta Elab Tactic Command

/--
The command `#help option` shows all options that have been defined in the current environment.
Each option has a format like:
```
option pp.all : Bool := false
  (pretty printer) display coercions, implicit parameters, proof terms, fully qualified names,
  universe, and disable beta reduction and notations during pretty printing
```
This says that `pp.all` is an option which can be set to a `Bool` value, and the default value is
`false`. If an option has been modified from the default using e.g. `set_option pp.all true`,
it will appear as a `(currently: true)` note next to the option.

The form `#help option id` will show only options that begin with `id`.
-/
syntax withPosition("#help " colGt &"option" (colGt ppSpace Parser.rawIdent)?) : command

private def elabHelpOption (id : Option Ident) : CommandElabM Unit := do
  let id := id.map (·.raw.getId.toString false)
  -- Keep the original `Name` for option lookup; `Name.mkSimple` on a dotted
  -- string like `"pp.all"` is not the same as `` `pp.all ``, so looking up by
  -- the display string would never show `(currently: …)` for real options.
  let mut decls : Std.TreeMap String (Name × OptionDecl) compare := {}
  for (name, decl) in show NameMap OptionDecl from ← getOptionDecls do
    let nameStr := name.toString false
    if let some id := id then
      if !id.isPrefixOf nameStr then
        continue
    decls := decls.insert nameStr (name, decl)
  let mut msg := Format.nil
  let opts ← getOptions
  if decls.isEmpty then
    match id with
    | some id => throwError "no options start with {id}"
    | none => throwError "no options found (!)"
  for (nameStr, (name, decl)) in decls do
    let mut msg1 := match decl.defValue with
    | .ofString val => s!"String := {repr val}"
    | .ofBool val => s!"Bool := {repr val}"
    | .ofName val => s!"Name := {repr val}"
    | .ofNat val => s!"Nat := {repr val}"
    | .ofInt val => s!"Int := {repr val}"
    | .ofSyntax val => s!"Syntax := {repr val}"
    if let some val := opts.find? name then
      msg1 := s!"{msg1} (currently: {val})"
    msg := msg ++ .nest 2 (f!"option {nameStr} : {msg1}" ++ .line ++ decl.descr) ++ .line ++ .line
  logInfo msg

elab_rules : command | `(#help option $(id)?) => elabHelpOption id

/--
The command `#help attribute` (or the short form `#help attr`) shows all attributes that have been
defined in the current environment.
Each attribute has a format like:
```
[inline]: mark definition to always be inlined
```
This says that `inline` is an attribute that can be placed on definitions like
`@[inline] def foo := 1`. (Individual attributes may have restrictions on where they can be
applied; see the attribute's documentation for details.) Both the attribute's `descr` field as well
as the docstring will be displayed here.

The form `#help attr id` will show only attributes that begin with `id`.
-/
syntax withPosition("#help " colGt (&"attr" <|> &"attribute")
    (colGt ppSpace Parser.rawIdent)?) : command

private def elabHelpAttr (id : Option Ident) : CommandElabM Unit := do
  let id := id.map (·.raw.getId.toString false)
  let mut decls : Std.TreeMap _ _ compare := {}
  /-
  #adaptation_note
  On nightly-2024-06-21, added the `.toList` here:
  without it the requisite `ForIn` instance can't be found.
  -/
  for (name, decl) in (← attributeMapRef.get).toList do
    let name := name.toString false
    if let some id := id then
      if !id.isPrefixOf name then
        continue
    decls := decls.insert name decl
  let mut msg := Format.nil
  let env ← getEnv
  if decls.isEmpty then
    match id with
    | some id => throwError "no attributes start with {id}"
    | none => throwError "no attributes found (!)"
  for (name, decl) in decls do
    let mut msg1 := s!"[{name}]: {decl.descr}"
    if let some doc ← findDocString? env decl.ref then
      msg1 := s!"{msg1}\n{doc.trimAscii}"
    msg := msg ++ .nest 2 msg1 ++ .line ++ .line
  logInfo msg

elab_rules : command
  | `(#help attr $(id)?) => elabHelpAttr id
  | `(#help attribute $(id)?) => elabHelpAttr id

/--
The command `#help cats` shows all syntax categories that have been defined in the
current environment.
Each syntax has a format like:
```
category command [Lean.Parser.initFn✝]
```
The name of the syntax category in this case is `command`, and `Lean.Parser.initFn✝` is the
name of the declaration that introduced it. (It is often an anonymous declaration like this,
but you can click to go to the definition.) It also shows the doc string if available.

The form `#help cats id` will show only syntax categories that begin with `id`.
-/
syntax withPosition("#help " colGt &"cats" (colGt ppSpace Parser.rawIdent)?) : command

private def elabHelpCats (id : Option Ident) : CommandElabM Unit := do
  let id := id.map (·.raw.getId.toString false)
  let mut decls : Std.TreeMap _ _ compare := {}
  for (name, cat) in (Parser.parserExtension.getState (← getEnv)).categories do
    let name := name.toString false
    if let some id := id then
      if !id.isPrefixOf name then
        continue
    decls := decls.insert name cat
  let mut msg := MessageData.nil
  let env ← getEnv
  if decls.isEmpty then
    match id with
    | some id => throwError "no syntax categories start with {id}"
    | none => throwError "no syntax categories found (!)"
  for (name, cat) in decls do
    let mut msg1 := m!"category {name} [{mkConst cat.declName}]"
    if let some doc ← findDocString? env cat.declName then
      msg1 := msg1 ++ Format.line ++ doc.trimAscii.copy
    msg := msg ++ .nest 2 msg1 ++ (.line ++ .line : Format)
  logInfo msg

elab_rules : command | `(#help cats $(id)?) => elabHelpCats id

/--
The command `#help cat C` shows all syntaxes that have been defined in syntax category `C` in the
current environment.
Each syntax has a format like:
```
syntax "first"... [Parser.tactic.first]
  `first | tac | ...` runs each `tac` until one succeeds, or else fails.
```
The quoted string is the leading token of the syntax, if applicable. It is followed by the full
name of the syntax (which you can also click to go to the definition), and the documentation.

* The form `#help cat C id` will show only attributes that begin with `id`.
* The form `#help cat+ C` will also show information about any `macro`s and `elab`s
  associated to the listed syntaxes.
-/
syntax withPosition("#help " colGt &"cat" "+"? colGt ident
    (colGt ppSpace (Parser.rawIdent <|> str))?) : command

private def tokensToList (tks : Parser.FirstTokens) : List String :=
  match tks with
  | .epsilon | .unknown => []
  | .tokens tks | .optTokens tks => tks

private def elabHelpCat (more : Option Syntax) (catStx : Ident) (id : Option String) :
    CommandElabM Unit := do
  let mut decls : Std.TreeMap _ _ compare := {}
  let mut rest : Std.TreeMap _ _ compare := {}
  let catName := catStx.getId.eraseMacroScopes
  let categories := (Parser.parserExtension.getState (← getEnv)).categories
  let some cat := categories.find? catName
    | throwErrorAt catStx "{catStx} is not a syntax category"
  liftTermElabM <| Term.addCategoryInfo catStx catName
  let mut declsArray : Array (SyntaxNodeKind × List String × Bool) := {}
  let mut tokenUsage : Std.HashMap String Nat := {}
  for (k, _) in cat.kinds do
    let mut used := false
    try
      let (leading, parser) ← liftCoreM <| Parser.mkParserOfConstant categories k
      let tks := tokensToList parser.info.firstTokens
      let tks := tks.filter (· != "$") -- filter antiquotations
      -- collect the usage of every token regardless of filtering to make sure that the
      -- token detection is independent of a filter
      for tk in tks.eraseDups do
        tokenUsage := tokenUsage.alter tk fun n => some (n.getD 0 + 1)
      if let some id := id then
        unless tks.any (·.startsWith id) do
          continue
      unless tks.isEmpty do
        used := true
        declsArray := declsArray.push (k, tks, leading)
    catch _ =>
      pure ()
    if !used && id.isNone then
      rest := rest.insert (k.toString false) k
  for (kind, tks, leading) in declsArray do
    -- we choose the first, least common token
    let winnerTk := tks.minOn? (tokenUsage[·]!) |>.get!
    decls := decls.alter winnerTk fun arr => some (arr.getD #[] |>.push (kind, leading))
  let mut msg := MessageData.nil
  if decls.isEmpty && rest.isEmpty then
    match id with
    | some id => throwError "no {catName} declarations start with {id}"
    | none => throwError "no {catName} declarations found"
  let env ← getEnv
  let addMsg (k : SyntaxNodeKind) (msg msg1 : MessageData) : CommandElabM MessageData := do
    let mut msg1 := msg1
    if let some doc ← findDocString? env k then
      msg1 := msg1 ++ Format.line ++ doc.trimAscii.copy
    msg1 := .nest 2 msg1
    if more.isSome then
      let addElabs {α} (type : String) (attr : KeyedDeclsAttribute α)
          (msg : MessageData) : CommandElabM MessageData := do
        let mut msg := msg
        for e in attr.getEntries env k do
          let x := e.declName
          msg := msg ++ Format.line ++ m!"+ {type} {mkConst x}"
          if let some doc ← findDocString? env x then
            msg := msg ++ .nest 2 (Format.line ++ doc.trimAscii.copy)
        pure msg
      msg1 ← addElabs "macro" macroAttribute msg1
      match catName with
      | `term => msg1 ← addElabs "term elab" Term.termElabAttribute msg1
      | `command => msg1 ← addElabs "command elab" commandElabAttribute msg1
      | `tactic | `conv => msg1 ← addElabs "tactic elab" tacticElabAttribute msg1
      | _ => pure ()
    return msg ++ msg1 ++ (.line ++ .line : Format)
  for (name, ks) in decls do
    for (k, leading) in ks do
      if leading then
        msg ← addMsg k msg m!"syntax {repr name}... [{mkConst k}]"
      else
        msg ← addMsg k msg m!"syntax ...{repr name}... [{mkConst k}]"
  for (_, k) in rest do
    msg ← addMsg k msg m!"syntax ... [{mkConst k}]"
  logInfo msg

elab_rules : command
  | `(#help cat $[+%$more]? $cat) => elabHelpCat more cat none
  | `(#help cat $[+%$more]? $cat $id:ident) => elabHelpCat more cat (id.getId.toString false)
  | `(#help cat $[+%$more]? $cat $id:str) => elabHelpCat more cat id.getString

open Lean Parser Batteries.Util.LibraryNote in
/--
`#help note "foo"` searches for all library notes whose
label starts with "foo", then displays those library notes sorted alphabetically by label,
grouped by label.
The command only displays the library notes that are declared in
imported files or in the same file above the line containing the command.
-/
elab "#help " colGt &"note" colGt ppSpace name:strLit : command => do
  let env ← getEnv

  -- get the library notes from both this and imported files
  let local_entries := (libraryNoteExt.getEntries env).reverse
  let imported_entries := (libraryNoteExt.toEnvExtension.getState env).importedEntries

  -- The key for searching and sorting library notes is their value as a string,
  -- without any «escaping using french quotes».
  let key (n : LibraryNoteEntry) := n.toString (escape := false)

  -- filter for the appropriate notes while casting to list
  let label_prefix := name.getString
  let imported_entries_filtered := imported_entries.flatten.toList.filterMap
    fun x => if label_prefix.isPrefixOf (key x) then some x else none
  let valid_entries := (imported_entries_filtered ++ local_entries.filterMap
    fun x => if label_prefix.isPrefixOf (key x) then some x else none)
    |>.mergeSort (key · ≤ key ·)

  -- display results in a readable style
  if valid_entries.isEmpty then
    logError "Note not found"
  else
    logInfo <| "\n\n".intercalate <|
      ← valid_entries.filterMapM
        fun x => do
          -- Use encoded name (spaces → underscores) for docstring lookup,
          -- matching the declaration name created by `library_note`
          let encodedName := encodeNameForExport x
          let some doc ← findDocString? env <| (`LibraryNote).eraseMacroScopes.append encodedName |
            return none
          return "library_note " ++ x.toString (escape := true) ++ "\n" ++
            "/-- " ++ doc.trimAscii ++ " -/"

/--
The command `#help term` shows all term syntaxes that have been defined in the current environment.
See `#help cat` for more information.
-/
syntax withPosition("#help " colGt &"term" "+"?
    (colGt ppSpace (Parser.rawIdent <|> str))?) : command
macro_rules
  | `(#help term%$tk $[+%$more]? $(id)?) =>
    `(#help cat$[+%$more]? $(mkIdentFrom tk `term) $(id)?)

/--
The command `#help tactic` shows all tactics that have been defined in the current environment.
See `#help cat` for more information.
-/
syntax withPosition("#help " colGt &"tactic" "+"?
    (colGt ppSpace (Parser.rawIdent <|> str))?) : command
macro_rules
  | `(#help tactic%$tk $[+%$more]? $(id)?) =>
    `(#help cat$[+%$more]? $(mkIdentFrom tk `tactic) $(id)?)

/--
The command `#help conv` shows all tactics that have been defined in the current environment.
See `#help cat` for more information.
-/
syntax withPosition("#help " colGt &"conv" "+"?
    (colGt ppSpace (Parser.rawIdent <|> str))?) : command
macro_rules
  | `(#help conv%$tk $[+%$more]? $(id)?) =>
    `(#help cat$[+%$more]? $(mkIdentFrom tk `conv) $(id)?)

/--
The command `#help command` shows all commands that have been defined in the current environment.
See `#help cat` for more information.
-/
syntax withPosition("#help " colGt &"command" "+"?
    (colGt ppSpace (Parser.rawIdent <|> str))?) : command
macro_rules
  | `(#help command%$tk $[+%$more]? $(id)?) =>
    `(#help cat$[+%$more]? $(mkIdentFrom tk `command) $(id)?)
