/-
Copyright (c) 2021 Mario Carneiro. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Carneiro
-/
module

public meta import Lean.Elab.Tactic.ElabTerm
public meta import Lean.Meta.MatchUtil

public meta section

/-!
# Simple tactics that are used throughout Batteries.
-/

namespace Batteries.Tactic
open Lean Parser.Tactic Elab Elab.Tactic Meta

/--
`_` in tactic position acts like the `done` tactic: it fails and gives the list
of goals if there are any. It is useful as a placeholder after starting a tactic block
such as `by _` to make it syntactically correct and show the current goal.
-/
macro "_" : tactic => `(tactic| {})

/--
`exacts [e1, ..., en]` is like `exact`, using the terms `e1`, ..., `en` to close all the current
`n` goals. It raises an error if the number of goals does not match.
-/
elab (name := exacts) "exacts " "[" hs:term,* "]" : tactic => do
  for stx in hs.getElems do
    evalTactic (← `(tactic| exact $stx))
  evalTactic (← `(tactic| done))

/--
`by_contra_core` is the component of `by_contra` that turns the goal into the form `p → False`.
`by_contra h` is defined as `by_contra_core` followed by `rintro h`.
* If the goal is a negation `¬q`, the goal becomes `q → False`.
* If the goal has a `Decidable` instance, it uses `Decidable.byContradiction` instead of
  `Classical.byContradiction`.
-/
scoped macro "by_contra_core" : tactic => `(tactic| first
  | guard_target = Not _; change _ → False
  | refine @Decidable.byContradiction _ _ ?_
  | refine @Classical.byContradiction _ ?_)

/--
`by_contra h` proves `⊢ p` by contradiction,
introducing a hypothesis `h : ¬p` and proving `False`.
* If `p` is a negation `¬q`, `h : q` will be introduced instead of `¬¬q`.
* If `p` is decidable, it uses `Decidable.byContradiction` instead of `Classical.byContradiction`.
* If `h` is omitted, the introduced variable will be called `this`.
* `h` can be any pattern supported by `rcases`/`rintro`.
-/
syntax (name := byContra) "by_contra" (ppSpace colGt rcasesPatMed)? (" : " term)? : tactic

macro_rules
| `(tactic| by_contra $[$pat?]? $[: $ty?]?) => do
  let pat ← pat?.getDM `(rcasesPatMed| $(mkIdent `this):ident)
  `(tactic| (by_contra_core; rintro ($pat:rcasesPatMed) $[: $ty?]?))

/--
Given a proof `h` of `p`, `absurd h` changes the goal to `⊢ ¬ p`.
If `p` is a negation `¬q` then the goal is changed to `⊢ q` instead.
-/
macro "absurd " h:term : tactic =>
  -- we can't use `( :)` here as that would make `·` behave weirdly.
  `(tactic|
    first
    | refine @absurd _ _ ?_ $h
    | refine @absurd _ _ $h ?_)

/-- `split_ands` applies `And.intro` on all goals until it does not make progress. -/
syntax "split_ands" : tactic
macro_rules | `(tactic| split_ands) => `(tactic| repeat' refine And.intro ?_ ?_)

/--
`fapply e` is like `apply e` but it adds goals in the order they appear,
rather than putting the dependent goals first.
-/
elab "fapply " e:term : tactic =>
  evalApplyLikeTactic (·.apply (cfg := {newGoals := .all})) e

/--
`eapply e` is like `apply e` but it does not add subgoals for variables that appear
in the types of other goals. Note that this can lead to a failure where there are
no goals remaining but there are still metavariables in the term:
```
example (h : ∀ x : Nat, x = x → True) : True := by
  eapply h
  rfl
  -- no goals
-- (kernel) declaration has metavariables '_example'
```
-/
elab "eapply " e:term : tactic =>
  evalApplyLikeTactic (·.apply (cfg := {newGoals := .nonDependentOnly})) e

/-- Deprecated variant of `trivial`. -/
elab (name := triv) "triv" : tactic => throwError "`triv` has been removed; use `trivial` instead"

/-- The `conv` mode tactic `exact e` closes the goal `⊢ t` by rewriting it to `t'`,
where `e : t = t'`. -/
macro (name := Conv.exact) "exact " t:term : conv => `(conv| tactic => exact $t)

/-- The `conv` mode tactic `equals e` claims that the currently focused subexpression is equal
to the term `e`, and proves this claim using the given tactic.
```
example (P : (Nat → Nat) → Prop) : P (fun n => n - n) := by
  conv in (_ - _) => equals 0 =>
    -- current goal: ⊢ n - n = 0
    apply Nat.sub_self
  -- current goal: P (fun n => 0)
```
-/
elab (name := Conv.equals) "equals " t:term " => " tac:tacticSeq : conv => do
  let mvarId ← getMainGoal
  mvarId.withContext do
    let goal ← mvarId.getType
    let some (α, _, rhs) ← matchEq? goal | throwError "invalid 'conv' goal"
    let e ← Term.withSynthesize do
      Term.elabTermEnsuringType t (some α)
    unless ← isDefEq rhs e do throwError m!"failed to resolve{indentExpr rhs}\n=?={indentExpr e}"
    evalTactic <| ← `(conv| tactic => · $tac)
