/-
Copyright (c) 2024 Jujian Zhang. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Jujian Zhang, Nailin Guan, Yuyang Zhao
-/
module

public import Mathlib.Algebra.Category.Grp.Basic
public import Mathlib.Basic.Finite.Defs

/-!
# The category of finite groups

## Main definitions and results

* `FiniteGrp` is the category of finite groups.

-/

@[expose] public section

universe u v

open CategoryTheory

/-- The category of finite groups. -/
@[pp_with_univ]
structure FiniteGrp where
  /-- A group that is finite -/
  toGrp : GrpCat.{u}
  [isFinite : Finite toGrp]

/-- The category of finite additive groups. -/
@[pp_with_univ]
structure FiniteAddGrp where
  /-- An additive group that is finite -/
  toAddGrp : AddGrpCat.{u}
  [isFinite : Finite toAddGrp]

attribute [to_additive] FiniteGrp

namespace FiniteGrp

@[to_additive]
instance : CoeSort FiniteGrp.{u} (Type u) where
  coe G := G.toGrp

@[to_additive]
instance : Category FiniteGrp :=
  inferInstanceAs <| Category (InducedCategory _ FiniteGrp.toGrp)

@[to_additive]
instance : ConcreteCategory FiniteGrp (· →* ·) :=
  inferInstanceAs <| ConcreteCategory (InducedCategory _ toGrp) _

@[to_additive]
instance (G : FiniteGrp) : Group G := inferInstanceAs <| Group G.toGrp

@[to_additive]
instance (G : FiniteGrp) : Finite G := G.isFinite

/-- Construct a term of `FiniteGrp` from a type endowed with the structure of a finite group. -/
@[to_additive /-- Construct a term of `FiniteAddGrp` from a type endowed with the structure of a
finite additive group. -/]
def of (G : Type u) [Group G] [Finite G] : FiniteGrp where
  toGrp := ↧G
  isFinite := ‹_›

/-- The morphism in `FiniteGrp`, induced from a morphism of the category `GrpCat`. -/
@[to_additive
/-- The morphism in `FiniteAddGrp`, induced from a morphism of the category `AddGrpCat` -/]
def ofHom {X Y : Type u} [Group X] [Finite X] [Group Y] [Finite Y] (f : X →* Y) : of X ⟶ of Y :=
  InducedCategory.homMk (GrpCat.ofHom f)

@[to_additive]
lemma ofHom_apply {X Y : Type u} [Group X] [Finite X] [Group Y] [Finite Y] (f : X →* Y) (x : X) :
    ofHom f x = f x :=
  rfl

end FiniteGrp

section Notation

open Lean.PrettyPrinter.Delaborator

/-- This prints `FiniteAddGrp.of X` as `↧X`. -/
@[app_delab FiniteAddGrp.of]
meta def FiniteAddGrp.delabOf : Delab := CategoryTheory.delabOf

/-- This prints `FiniteGrp.of X` as `↧X`. -/
@[app_delab FiniteGrp.of]
meta def FiniteGrp.delabOf : Delab := CategoryTheory.delabOf

end Notation
