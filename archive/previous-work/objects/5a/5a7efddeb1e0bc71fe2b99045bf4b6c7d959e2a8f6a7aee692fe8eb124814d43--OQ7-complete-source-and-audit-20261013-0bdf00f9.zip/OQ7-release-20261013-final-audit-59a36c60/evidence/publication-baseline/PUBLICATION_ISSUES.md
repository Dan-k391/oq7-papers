# Paper 1: final prepublication issue tracker

**Manuscript:** Unit Absorption Asymmetry at Prescribed Extinction for Compact Reciprocal Dielectrics  
**Baseline audit/correction:** 2026-10-12; **final minor pass:** 2026-10-13  
**Disposition:** Focused correction pass completed in the publication working directory. Original manuscripts and the frozen Lean repository are preserved. Nothing was published, submitted, or uploaded.

**Current ticket status:** 10 resolved for the professor-review package, 1 unresolved audit-evidence ticket, and 3 requiring human approval. The original findings and their CONFIRMED/LIKELY/NEEDS EXPERT REVIEW classifications below are retained as historical evidence; the added disposition field records the correction result.

## Latest minor pass: 13 October 2026

Figure 1 moved to PDF page 7, leaving Eq. (16)'s continuation on page 6 uninterrupted. Section 10 now explicitly labels the archived older audit as AI-assisted and states that no final-commit independent audit is archived with these materials. The fresh search still did not locate the claimed final report; P1-01 remains unresolved and no independent-PASS claim was added.

All theorem and proof text, 51 numbered equations, the 20-entry bibliography, and the figure caption/assets are unchanged from the latest 16-page baseline. The final PDF remains 16 pages. S4 and the supplement index are dated to this recheck; all actual linked files are included. No additional internal drafting notes were found. Authorship and disclosures remain pending explicit approval. Ticket totals remain 10 resolved for professor review, 1 unresolved, and 3 requiring human approval.

See [minor changelog](CHANGELOG.txt), [exact manuscript diff](review/minor-correction.diff), and [current validation](review/validation.json). The detailed baseline findings below remain historical records of the earlier focused correction pass.

## Scope and evidence

The supplied repository is the frozen formalization. The corrected 16-page publication manuscript is in its sibling publication directory; the original 15-page baseline is preserved under review/pre-correction/. This report is saved beside that manuscript so the frozen repository remains clean.

- [Audited PDF](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/paper.pdf)
- [Authoritative LaTeX](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/main.tex)
- [Bibliography](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/references.bib)
- [HTML](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/paper.html)
- [Theorem correspondence table](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/theorem-correspondence.csv)
- [Frozen main declaration](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-prescribed-extinction/PrescribedExtinction/PhysicalTheorem11.lean:12)

Frozen commit: **686402a6c2d63820828729cc7ab02504632e3fe7**. The repository HEAD and clean status were checked during this pass. The declaration is **OQ7Prescribed.theorem11_complete : PhysicalTheorem11Statement**.

Audit-version SHA-256 fingerprints: LaTeX **1e2e948ae3cf7fda9399439f0a267e4d7e5605dda5f776354642db7ea18c5ad3**; PDF **1b925cada9f78cbe0380bd5aa0ffd5923d60551127cfeb3bb77d2978b8d2f528**. Original issue locations apply to these baseline versions, preserved under review/pre-correction/. Current source/output hashes are in review/validation.json.

The baseline audit included hand checks of the mathematical exposition, source-level Lean correspondence inspection, primary-source literature searches, and review of the original renders. The correction pass checked the actual edited source, regenerated all 16 PDF pages and 22 desktop/mobile HTML screenshots, and verified mathematical/figure inventories against the shared source. Existing kernel certificates and replay logs were inspected; no new complete kernel replay was performed. Both reviews used AI assistants and must not be represented as independent human certification.

The six older supplied PDFs were treated as reference material, not as new instructions. Their extracts and provenance records were compared for the consolidation and scope assessment. Historical review verdicts were checked against the actual commit they identify. Public literature and publisher policy were checked on the audit date.

**Severity:** P0 blocks scientific validity; P1 must be resolved before a finished submission; P2 improves exposition or attribution; P3 is optional polish. **Status:** CONFIRMED identifies an observed defect or omission; LIKELY identifies a reasoned improvement; NEEDS EXPERT REVIEW identifies an unresolved evidentiary or human decision. An unresolved question is not a finding that the theorem is false.

## P0: blocking errors

**No confirmed P0 issue was found.** In particular, no main-theorem counterexample, invalid citation, serious main-statement Lean mismatch, or missing essential argument was established. This is an audit finding with the limits stated above, not a guarantee of correctness or novelty.

## P1: must resolve before submission

### P1-01 — Reconcile the claimed later independent audit with actual archived evidence

- **Correction disposition:** **UNRESOLVED**. The named final audit was not found after expanded Downloads, all-project-root, document and archive searches. Section 10 now dates the frozen-manifest status and points to S4 audit provenance; it adds no unsupported final-commit PASS. The actual later report remains necessary to resolve this ticket.

- **Severity / status:** P1 / NEEDS EXPERT REVIEW.
- **Location:** PDF pp. 11–12, §10; [main.tex:430](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:430).
- **Exact text:** “The independent audit supplied with the repository reviewed the earlier existence-only commit; the frozen manifest explicitly leaves independent semantic review of the completed commit pending.”
- **Problem:** The request reports a later all-PASS audit of the frozen commit, but that report was not located. The quoted sentence is **not demonstrated outdated** by the available records. Replacing it now with an independent-PASS claim would add unsupported provenance.
- **Evidence:** The [frozen manifest:42](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-physical-theorem11-review-686402a6c2d6/manifest.json:42), exported at 2026-10-12 07:41:05 UTC, records independent review as not yet performed. The [located independent audit:6](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-prescribed-extinction/verification/claude-independent-audit-5a8350d.md:6) covers **5a8350d5408c38e333c9f6b6d8a94816c794120b**, not 686402a6. Its lines 15–17 say PASS kernel, FAIL semantic fidelity, and FAIL completeness at that older stage. Downloads/AUDIT_REPORT.md is byte-identical to it, SHA-256 **50d854e335d44cdf1d5a3710f3bc542a4a1a6c28593a46cd320a2ea6ed9f7245**. Searches covered project outputs, attachments, Downloads, relevant Documents/Codex records, and eight relevant accessible chats. Failure to locate the later report does not prove it does not exist.
- **Proposed correction:** Obtain the actual later report and identify its author/tool, date, exact commit, principal declaration, methods, scope, verdicts, and limitations. Cite it separately from the frozen export manifest. If it cannot be obtained, retain the qualified status and date the provenance: “The export manifest records independent semantic review as pending at the time of freezing; the archived independent audit applies to the earlier commit.” Do not carry the old FAIL verdict forward to the completed theorem.
- **Mathematical meaning:** No theorem change. Changes only the supported verification claim.
- **Verification after correction:** Confirm the report explicitly covers the final commit, both suprema and F1–F4; inspect its reasoning rather than accepting its verdict alone. Distinguish semantic review from kernel replay and from an independently implemented kernel.

### P1-02 — Add the directly relevant Khurgin et al. 2021 mechanism precedent

- **Correction disposition:** **RESOLVED**. Added Khurgin2021 with verified metadata and a mechanism comparison in Section 2. The genuine 2011 citation remains only as separate loss/confinement context.

- **Severity / status:** P1 / CONFIRMED.
- **Location:** PDF p. 2, §2; [main.tex:44](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:44); current entry [references.bib:45](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/references.bib:45).
- **Exact text:** “The supplied priority report does not identify a more specific Khurgin comparison; that bibliographic question remains open for expert review.”
- **Problem:** A specific, closer mechanism paper has now been identified and read. The existing Khurgin–Sun 2011 citation is genuine, but its plasmonic loss-scaling context does not replace this comparison.
- **Evidence:** J. B. Khurgin, Y. Sebbag, E. Edrei, R. Zektzer, K. Shastri, U. Levy, and F. Monticone, “Emulating exceptional-point encirclements using imperfect (leaky) photonic components: asymmetric mode-switching and omni-polarizer action,” **Optica 8(4), 563–569 (2021), DOI 10.1364/OPTICA.412981**. The actual paper's §4, pp. 566–568, treats selective attenuation and a leaky waveplate, including passive attenuator experiments. [Publisher](https://opg.optica.org/optica/fulltext.cfm?uri=optica-8-4-563); [author-hosted paper](https://openscholar.huji.ac.il/sites/default/files/uriellevy/files/emulating_exceptional-point_encirclements_using_imperfect_eaky_photonic_components_asymmetric_mode-switching_and_omni-polarizer_action.pdf).
- **Proposed correction:** Replace the unresolved-comparison sentence with a cited mechanism acknowledgment. Distinguish that channel/device mechanism from the present compact-body, exact-extinction, capped-dielectric and uniform-aperture statement. Keep the 2011 paper only if its separate material-loss context remains useful.
- **Mathematical meaning:** None. This reduces the scope of any mechanism-novelty implication.
- **Verification after correction:** Check complete author metadata and DOI in the regenerated bibliography; ensure the comparison does not attribute the present quantified theorem to the 2021 paper or claim its absence as a proven priority result.

### P1-03 — Remove internal drafting language and uncited antecedent-manuscript references

- **Correction disposition:** **RESOLVED**. Removed private priority-assessment language, uncited preceding/source-manuscript narrative, historical annotation story and human to-do text from the scientific manuscript. Retained Mann–Alù priority uncertainty and the proof-organization qualification.

- **Severity / status:** P1 / CONFIRMED.
- **Location:** PDF pp. 1–2, §§1–2, and pp. 11–12, §10; [main.tex:37](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:37), lines 44, 46, 52, 426, 428, 430, 432.
- **Exact text:** “The preceding compact-Maxwell study established an unrestricted unit supremum”; “The prescribed-extinction manuscript resolved this”; “We consolidate that argument here”; “as discussed in the source manuscript”; “The available novelty assessment is provisional and incremental. The proof is evaluated independently of that assessment.” Section 10 additionally refers to a “supplied correspondence table,” a “supplied analytical proof,” and ends with “The author, affiliation, acknowledgments, and disclosure fields require human confirmation before submission.”
- **Problem:** Readers cannot identify the uncited antecedent studies. The manuscript mixes scientific positioning with package history and author to-do notes. Its priority caution is appropriate, but a private novelty assessment is not a scientific authority.
- **Evidence:** The bibliography has no entries identifying those preceding/source manuscripts or the private priority report. The supplied PDFs and provenance file identify their local filenames, not public authorship and archival status.
- **Proposed correction:** Rewrite §1 around the scientific obstacle: a fixed-angle planar limit grows extinction with area; exact rotation factorization and uniform localization permit simultaneous aperture growth and fixed total extinction. State the contribution directly in §2 while retaining the specific unresolved Mann–Alù comparison. Either cite publicly identifiable antecedent works with author-approved metadata, or eliminate the historical manuscript narrative. Replace “supplied” table/proof references with named, numbered supplementary references (P1-06). Move historical formalization corrections to the verification supplement and author to-do notes to this tracker. Retain the scientifically important distinction between proof organizations.
- **Mathematical meaning:** None, provided the hypotheses, resource qualifications, proof-scope distinction, and priority uncertainty survive.
- **Verification after correction:** Search for “supplied,” “preceding,” “source manuscript,” “available novelty assessment,” and “human confirmation.” Check every retained antecedent reference has an actual citation. Compare the revised contribution statement with Theorem 4.1.

### P1-04 — Supply human authorship and contact information

- **Correction disposition:** **REQUIRING HUMAN APPROVAL**. Names, author order, affiliations and contact remain unspecified, as explicitly instructed. No author information was invented.

- **Severity / status:** P1 / CONFIRMED.
- **Location:** PDF p. 1, title block; [main.tex:24](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:24); author to-do sentence at line 432, PDF p. 12.
- **Exact source:** \author{}.
- **Problem:** No author name, affiliation, or corresponding-author contact is supplied. The visibly empty title block cannot serve as completed publication front matter.
- **Evidence:** Both PDF and HTML omit authorship. No verified information in the manuscript fills these fields.
- **Proposed correction:** Have the responsible human author approve names, order, affiliations or independent-researcher designation, contact, and any required contribution statement. Use only confirmed information and the chosen venue's format. Remove the to-do sentence from §10 after the fields are completed.
- **Mathematical meaning:** None.
- **Verification after correction:** Human approval of attribution and contact; inspect the title block and HTML metadata for consistency and layout.

### P1-05 — Complete factual funding, acknowledgments, and conflict declarations

- **Correction disposition:** **REQUIRING HUMAN APPROVAL**. Funding, acknowledgments and conflicts remain unspecified. No no-funding/no-conflict declaration or endorsement was invented.

- **Severity / status:** P1 / CONFIRMED omission; applicability and content require human input.
- **Location:** PDF p. 12, §10, and end matter; [main.tex:432](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:432); bibliography begins at lines 479–480.
- **Exact text:** “The author, affiliation, acknowledgments, and disclosure fields require human confirmation before submission.” No completed Funding, Disclosures, or Acknowledgments statement occurs before the bibliography.
- **Problem:** A to-do sentence does not provide actual declarations. Whether a separate acknowledgment section is needed depends on actual contributions and venue requirements.
- **Evidence:** The source lacks these sections. As a concrete venue example, Optica Publishing Group requires a Disclosures statement for most of its journals and separates acknowledgments, funding, and disclosures. [Current general policies](https://opg.optica.org/content/author/portal/item/review-general-policies).
- **Proposed correction:** Ask the author to confirm funding and grant identifiers, relevant financial/nonfinancial conflicts, and contributors to acknowledge. Insert only truthful declarations in the target format. Do not assume “no funding” or “no conflicts,” and do not invent endorsements from professors or auditors.
- **Mathematical meaning:** None.
- **Verification after correction:** Human factual approval and a check against the chosen journal's current instructions.

### P1-06 — Make the formalization and supplements identifiable and accessible

- **Correction disposition:** **RESOLVED FOR PROFESSOR REVIEW**. Section 10 names and links S1–S4 and the actual supplement index, with frozen source, toolchain/dependencies, mapping and evidence. Local review access is resolved. Public archival location and venue-specific deposition remain human decisions before release/submission.

- **Severity / status:** P1 / CONFIRMED.
- **Location:** PDF pp. 11–12, §10; [main.tex:424](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:424), lines 428 and 430; related “No numerical simulation or experimental data” statement at line 414, PDF p. 11.
- **Exact text:** “The source is \path{PrescribedExtinction/PhysicalTheorem11.lean}”; “The supplied correspondence table distinguishes direct declarations”; “A current declaration check and separate replay log accompany this publication package.”
- **Problem:** The PDF names local paths and package contents but provides no repository/archive citation or numbered supplement pointer. A reader receiving only the PDF cannot obtain the formalization or find the promised correspondence and logs. The absence of experimental data does not remove the need to explain access to the proof code.
- **Evidence:** The local package already contains a source ZIP, Git bundle, manifest, correspondence table, and check/replay evidence. Those are useful reproducibility materials, but none has an author-approved public identifier or an explicit supplemental citation in the manuscript.
- **Proposed correction:** Add a factual data/code/formalization availability statement and named supplement references. Identify the frozen commit, Lean/toolchain/dependency versions, principal declaration, source archive, theorem table, and verification evidence. Before an authorized release, choose a durable access location or a truthful availability-on-request statement if the venue permits it. Distinguish no empirical data from the existence of formal proof code. This audit does not authorize uploading anything.
- **Mathematical meaning:** None; improves inspectability of the existing claim.
- **Verification after correction:** Confirm every identifier and access statement is real; verify archive contents and source hashes match the frozen commit; open all supplement/repository links from the standalone PDF and HTML.

### P1-07 — Resolve target-journal compatibility and the factual AI-assistance account

- **Correction disposition:** **REQUIRING HUMAN APPROVAL**. No assistance declaration was invented. Target journal and factual assistance account remain undecided. Conditional Optica generated-text compatibility issue remains; disclosure alone must not be assumed sufficient.

- **Severity / status:** P1 / NEEDS EXPERT REVIEW.
- **Location:** PDF p. 12, §10; [main.tex:432](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:432); no AI statement appears elsewhere.
- **Exact text:** “The author, affiliation, acknowledgments, and disclosure fields require human confirmation before submission.”
- **Problem:** No target journal or factual assistance statement is specified. This package was consolidated with AI assistance; a claim of grammar-only assistance cannot simply be assumed. Some venues impose restrictions beyond disclosure.
- **Evidence:** The current Optica policy permits enhancement/editing of original text but prohibits AI generation of text; it also requires documentation of generated figures/media/code. AI cannot be an author. This is a conditional venue-compatibility concern, not a finding of a violation at an unselected journal. [Policy](https://opg.optica.org/content/author/portal/item/review-general-policies).
- **Proposed correction:** The human author should identify the target venue and approve an accurate account of assistance in prose, proof/code development, literature work, and review. Check that workflow against the actual venue policy. If necessary, obtain editorial clarification or prepare author-written text under that policy. Do not assume that adding an acknowledgment alone resolves a prohibited workflow.
- **Mathematical meaning:** None to the theorem; responsibility for the scientific content remains human.
- **Verification after correction:** Human review of the account, current venue-policy check, and consistency with any submission forms. Avoid unsupported claims that every result received independent human validation.

## P2: recommended improvements

### P2-01 — Separate the global Fourier auxiliary field from its aperture restriction

- **Correction disposition:** **RESOLVED**. Eq. (35) now transforms the unrestricted auxiliary field H-tilde on the transverse strip; H denotes its restriction. Low-frequency L2, high-frequency Linfinity, density, residual and uniform-power estimates were rechecked without changing Theorems 4.1 or 7.1.

- **Severity / status:** P2 / CONFIRMED.
- **Location:** PDF p. 8, §7.2, Eq. (35), with continuation on p. 9; [main.tex:321](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:321), lines 322–337. Restricted Green operator defined at lines 131–134.
- **Exact text/equation:** “the projected commutator \(H_{R,\theta}=J_\theta^*K_{D_R}J_\theta(v_Rr)-v_RB_{\mathbf0,\theta}r\) has transverse representation”
  \[
  \widehat H_{R,\theta}(\kappa)
  =R^2\widehat v(R\kappa)(B_{\kappa,\theta}-B_{\mathbf0,\theta})r.
  \]
- **Problem:** \(K_{D_R}\) was defined as the field restricted to \(D_R\). Thus this \(H\) is a finite-aperture field. Its zero extension has an additional aperture-window convolution in Fourier space and does not literally satisfy Eq. (35). The intended mixed-estimate proof uses an unrestricted observation field and restricts it only afterward.
- **Evidence/derivation:** For a global auxiliary \(\widetilde H\), transverse translation invariance gives the displayed multiplier identity. For the zero extension of its restriction, \(\widehat{\mathbf1_{S_R}\widetilde H}=(2\pi)^{-2}\widehat{\mathbf1_{S_R}}*\widehat{\widetilde H}\). Lines 328–337 already use the intended low-frequency global \(L^2\) estimate and high-frequency global \(L^\infty(\mathcal H)\) estimate, followed by a finite-body \(L^2\) restriction.
- **Proposed correction:** Define \(\mathcal Kp=(k^2I+\nabla\nabla\cdot)(g_k*\widetilde p)\) without observation restriction, where the source is zero-extended in three dimensions. Define \(\widetilde H_{R,\theta}=J_\theta^*\mathcal K(J_\theta(v_Rr))-v_RB_{\mathbf0,\theta}r\) on \(\mathbb R^2\times(0,L)\), extending the layer-axis multiplication transversely. Set \(H_{R,\theta}=\widetilde H_{R,\theta}|_{D_R}\). Apply Eq. (35) to \(\widehat{\widetilde H}\), distributionally before the mixed estimates.
- **Mathematical meaning:** No change to the theorem or intended argument. It repairs the domain of an intermediate identity. It must not be replaced with a global \(L^2\) claim across the grazing circle.
- **Verification after correction:** Re-derive the Weyl identity using the global definition; check all later occurrences refer to the appropriate field; regenerate PDF/HTML. This small correction should be completed before asking a specialist to review the proof.

### P2-02 — Add one explanatory two-layer schematic

- **Correction disposition:** **RESOLVED**. Added one vector schematic from a shared drawing specification, as PDF for LaTeX and embedded SVG for HTML. It shows layer order, finite square aperture, thicknesses, opposite incidence, common y polarization and rotated plate axis; caption distinguishes intermediate and final loss.

- **Severity / status:** P2 / LIKELY.
- **Location:** PDF p. 3, §3, and pp. 5–7, §6; [main.tex:62](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:62), lines 176–183 and 258–259.
- **Exact scientific anchor:** \(\chi_A=i\eta e_xe_x^T,\quad \chi_{W,\theta}=(a+i\delta)u_\theta u_\theta^T,\quad u_\theta=\cos\theta e_x+\sin\theta e_y\). There is no construction figure.
- **Problem:** Geometry, layer order, polarization axes, and opposite illumination must currently be reconstructed from equations spread across sections. A concise schematic would materially shorten that cognitive step.
- **Evidence:** The directional mechanism depends on whether the wave encounters the absorber or plate first, while both incident electric fields are polarized along \(e_y\).
- **Proposed correction:** Add a vector schematic of the finite square aperture \(R\), thicknesses \(h,d\), interfaces \(z=0,h,h+d\), axes \(e_x,e_y,e_z,u_\theta\), vacuum, and \(\pm e_z\) illumination with common \(e_y\) polarization. Explain the plate-to-absorber conversion in its caption. Label the rank-one tensors as intermediate; the final object has positive isotropic loss \(\nu I\) added. Mark it not to scale. No numerical field maps or performance curves are needed.
- **Mathematical meaning:** None.
- **Verification after correction:** Check plus/minus direction and layer labels against Eq. (1), the body definition, and Lemma 6.1; inspect legibility in PDF and narrow HTML; verify the figure has descriptive alternative text.

### P2-03 — Cite the planar optical-theorem and scattered-transmission precedent

- **Correction disposition:** **RESOLVED**. Added Gustafsson2012 and cited planar extinction/vacuum-subtraction precedent in Sections 2 and 6. The periodic versus compact-aperture distinction is retained.

- **Severity / status:** P2 / CONFIRMED attribution opportunity.
- **Location:** PDF p. 2, §2, and p. 7, Lemma 6.1; [main.tex:48](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:48), line 259.
- **Exact text:** “The planar optical theorem is \(X_\infty=2(1-\Re t_{\mathrm{co}})\), with scattered transmission defined by subtracting the vacuum wave.”
- **Problem:** The formula is correct, but a directly relevant planar extinction precedent is absent. This convention should receive explicit attribution.
- **Evidence:** M. Gustafsson, I. Vakili, S. E. Bayer Keskin, D. Sjöberg, and C. Larsson, “Optical theorem and forward scattering sum rule for periodic structures,” **IEEE Transactions on Antennas and Propagation 60(8), 3818–3826 (2012), DOI 10.1109/TAP.2012.2201113**. Its §2, Eqs. (2.3)–(2.6), distinguishes transmitted from scattered-transmitted power and derives \(P_s=P_r+|1-T|^2P_i+P_{t1}\) and \(\sigma_{\rm ext}=2\Re(1-T)A\). [Institutional record](https://lup.lub.lu.se/search/publication/2342759); [actual postprint](https://lup.lub.lu.se/search/files/96358663/TEAT_7213.pdf).
- **Proposed correction:** Cite it in the prior-work paragraph and/or at the planar optical theorem. Explain that its periodic-slab setting differs from literal compact-material truncation and the present uniform normalized limit.
- **Mathematical meaning:** None.
- **Verification after correction:** Verify metadata and normalization; retain the explicit vacuum subtraction. Do not use the periodic theorem as a substitute for §7's aperture proof.

### P2-04 — Include restrained acknowledgment of Yazdi et al. 2015

- **Correction disposition:** **RESOLVED WITH LIMITED COMPARISON**. Added Yazdi2015 with verified metadata and qualitative asymmetric-metasurface acknowledgment only. Detailed equation-level comparison remains unavailable; no unsupported equivalence or numerical maximum was added.

- **Severity / status:** P2 / LIKELY; exact equation-level comparison NEEDS EXPERT REVIEW.
- **Location:** PDF p. 2, §2; [main.tex:42](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:42), line 46.
- **Exact text:** “Related layered and metasurface devices also require explicit comparison.” The following comparison includes Kononchuk 2019 and Máñez-Espina 2026 but omits Yazdi 2015.
- **Problem:** An earlier, closely titled asymmetric-absorption metasurface paper should be acknowledged. The accessible evidence supports its bibliographic identity, but not a detailed equivalence verdict.
- **Evidence:** M. Yazdi, M. Albooyeh, R. Alaee, V. Asadchy, N. Komjani, C. Rockstuhl, C. R. Simovski, and S. Tretyakov, “A Bianisotropic Metasurface With Resonant Asymmetric Absorption,” **IEEE Transactions on Antennas and Propagation 63(7), 3004–3015 (2015), DOI 10.1109/TAP.2015.2423855**. [Aalto record](https://research.aalto.fi/en/publications/a-bianisotropic-metasurface-with-resonant-asymmetric-absorption/); [KIT record](https://publikationen.bibliothek.kit.edu/110103067). Complete equations were not retrieved in this pass. Retrieval failure is not invalidity.
- **Proposed correction:** Add a restrained acknowledgment of earlier bianisotropic metasurface asymmetric absorption. Obtain the actual article before making a stronger assertion about its constitutive class, numerical maximum, normalization, or theorem equivalence.
- **Mathematical meaning:** None; may refine positioning after full-text review.
- **Verification after correction:** Verify the author list and DOI; match each substantive comparison to the actual article rather than inferring it from the title.

### P2-05 — State the planar amplitude reference planes and vacuum phases explicitly

- **Correction disposition:** **RESOLVED**. Defined layer and stack boundary-plane amplitude conventions, t_co vacuum normalization and unit right-plane incidence phase. Appendix B subtracts the same vacuum transmitted factor in both directions. Both cascades and their vacuum/zero-loss limits were rechecked.

- **Severity / status:** P2 / CONFIRMED clarity gap.
- **Location:** PDF p. 6, §6.1; p. 7, Lemma 6.1; p. 13, Appendix B; [main.tex:235](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:235), lines 261 and 462–475.
- **Exact text:** “Let \(s=\sin\theta\), \(c=\cos\theta\), \(v_A=e^{ikh}\), \(v_W=e^{ikd}\), \(\Delta=t_W-v_W\), and \(D=1-r_Ar_Wc^2\). With output order \((Lx,Ly,Rx,Ry)\), subtract the vacuum transmitted wave and divide by \(s\).”
- **Problem:** The formulas are correct under a consistent boundary-plane convention, but Appendix B does not explicitly tell the reader where the incident/output amplitudes are referenced or how the global incident phases are removed. This matters when converting \(t_A,t_W\) into \(t_{\rm co}\) and subtracting a vacuum wave.
- **Evidence:** Independent cascade derivation reproduced all four entries of both amplitude vectors. At \(\delta=0\), their squared norms recover Eq. (26). A supplementary 36-case numerical algebra check agreed to \(1.19\times10^{-13}\) in normalized amplitude. Thus this is a convention clarification, not an identified amplitude error.
- **Proposed correction:** State that layer reflection/transmission coefficients are referenced to the adjacent boundary planes; identify \(L:z=0\), \(R:z=h+d\), and the unit incident amplitude convention for each direction. Specify the vacuum transmitted factor \(v_Av_W\) and that overall unit-modulus incident phase factors do not change powers. Retain the output-channel ordering.
- **Mathematical meaning:** None under the convention used by the present formulas.
- **Verification after correction:** Repeat the two Jones cascades with the declared conventions, verify Eq. (28), and check the vacuum and zero-plate-loss limits.

## P3: optional refinements

### P3-01 — Explain stale historical comments in the frozen Lean source

- **Correction disposition:** **RESOLVED**. S4 gives a historical-comment erratum pointing to completed optical/physical declarations. Frozen Lean comments and commit were not changed.

- **Severity / status:** P3 / CONFIRMED.
- **Location:** No faulty PDF statement; related discussion is PDF pp. 11–12, §10, [main.tex:424](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:424), line 430. Actual text is in [Maxwell.lean:103](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-prescribed-extinction/PrescribedExtinction/Maxwell.lean:103), lines 104 and 112–113.
- **Exact text:** “Identifying this current expression with the outgoing field flux is still unproved.” Also: “The exact requested statement, as an UNPROVED proposition. No proof declaration for this proposition is present in this partial project.”
- **Problem:** These historical comments can mislead someone inspecting the frozen source after completion.
- **Evidence:** PhysicalTheorem11.lean:12–31 proves the complete aggregate; FullPhysicalOpticalTheorem.lean:13–29 includes the physical sphere-flux identification. The manuscript accurately states completion.
- **Proposed correction:** Add a short historical-comment erratum in an external verification README/supplement that points to the completed declarations. **Do not change the frozen source or commit for this publication.**
- **Mathematical meaning:** None; comments do not alter declarations.
- **Verification after correction:** Check the erratum's declaration names and confirm the source archive remains byte-identical to the frozen commit.

### P3-02 — Make horizontal equation scrolling easier to discover on mobile

- **Correction disposition:** **RESOLVED**. Added overflow-only equation access hints and keyboard focus in HTML. Desktop 1440-px and mobile 390-px checks pass; full Eq. (9) is reachable by keyboard and local scrolling. The vector figure also has a full-size access link, and the Lean source filename now displays in HTML as well as PDF.

- **Severity / status:** P3 / CONFIRMED presentation behavior; benefit of an affordance is editorial.
- **Location:** HTML at 390 px, e.g. Theorem 4.1 Eq. (9), corresponding PDF p. 4; [main.tex:110](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/main.tex:110); actual presentation control [template.html:26](C:/Users/Daniel/.codex/.chatgpt-projects/g-p-6ac8784424248191b154eb2ed308e1f1/outputs/oq7-paper1-publication/review/pre-correction/template.html:26), lines 27–32.
- **Exact anchors:** Eq. (9) contains \(1-\epsilon<\Gamma<1\). The template uses “overflow-x:auto” and “min-width:max-content”.
- **Problem:** On a narrow initial view, some final terms sit offscreen within an intentionally scrollable equation panel; Eq. (9)'s final 1 is an example. Existing screenshots give little indication of horizontal access.
- **Evidence:** The existing 390-px QA record identifies 25 locally scrolling equations while the document itself stays at viewport width. This is not demonstrated inaccessible clipping. All 51 equation labels agree with the LaTeX auxiliary labels.
- **Proposed correction:** Add a subtle, accessible overflow indication only when a panel actually overflows, or split selected long equations without changing their content. Avoid page-wide horizontal scrolling.
- **Mathematical meaning:** None.
- **Verification after correction:** Test touch and keyboard access to the full formula and equation number at 390 px; recheck desktop layout, internal links, and native MathML.

## Baseline audit findings and continuing scientific qualifications

### Mathematical consistency and completeness

The central prescribed-extinction argument appears preserved. The following were checked independently rather than accepted from prior audit conclusions:

| Check | Location | Result and limit |
|---|---|---|
| Cross-section dimensions, sign convention, optical-theorem factor | §3, pp. 3–4; Eqs. (3)–(8) | Consistent with unit electric amplitude, \(e^{-i\omega t}\), conjugate-linear-first pairing, and area-valued cross sections. |
| Dyadic Green norm and radiation form | §5, pp. 4–5; Eqs. (11)–(13) | Kernel derivatives, radial/tangential bounds and Schur constant reproduce Eq. (12); sphere identity gives nonnegative radiation. |
| Strict-loss coercivity and reconstruction | §5, p. 5 | \(-\Im_H\chi^{-1}=\chi^{-\dagger}(\Im_H\chi)\chi^{-1}\), lower bound \(m/M^2\), Lax–Milgram, and weak Maxwell reconstruction are consistent. |
| Reciprocity | §§3, 5 | Bilinear symmetry and the specified real opposite polarization pair give equal extinction. No general circular-polarization equivalence is asserted. |
| Rank-one intermediate objects | §6, pp. 5–6 | Loss-free null axes are expressly intermediate. Active coercivity remains positive; full vector radiation is retained. |
| Exact rotation factorization | §6, Eq. (21) | \(J_\theta^*f_\pm=\sin\theta\,g_\pm\) yields current and power factors exactly; the auxiliary zero-angle state remains well-defined. |
| Plate, absorber, and planar powers | §6, pp. 6–7; Appendix B | Reflectionless phases, arbitrary \(P>1\), \(0<A_x<1\), absorber limit, and both amplitude vectors check. P2-05 clarifies phase conventions. |
| Zero-plate-loss continuity | Appendix B, p. 13 | Fredholm/nullvector and passive flux/ODE uniqueness argument supplies the regular limit; no false uniform loss-to-zero coercivity bound is used. |
| Uniform normalized aperture theorem | §7, pp. 8–9 | Correct low/high Fourier split after P2-01's domain clarification. Grazing inverse-square-root singularity is locally \(L^1\), not assumed globally \(L^2\). High-frequency radial tail is integrable for \(N>3\). |
| Sharp finite-body passage | §7 | Windows occur in trial currents, not material smoothing. The fixed-window, large-aperture, density-approximation order is correct. Power forms and positive normalized denominator support the quotient limit. |
| First exact-extinction IVT | §8.1, pp. 9–10 | Shrinking endpoint angles give limits \(E_*/2\) and \(2E_*\); finite-aperture continuity suffices. No monotonicity is assumed. |
| Positive isotropic loss and second IVT | §8.2, p. 10 | Fixed-body electric inverse/Neumann bound gives continuity on the angle bracket, preserving endpoint and asymmetry margins before exact retuning. |
| Final tensor caps | §8.2 | Real eigenvalues stay within \([1,P]\); losses \(\eta+\nu,\delta+\nu,\nu\) remain strictly positive and below \(Q\) with the chosen margins. |
| Strict nonattainment and both suprema | §4, p. 4 | Zero total scattering forces zero continuous far field and zero extinction; positive-target equality is impossible. Exact extinction converts the second supremum to \(E_*\). |
| Entire outgoing weak vacuum uniqueness | Appendix A, pp. 12–13 | Weighted Poynting and bilinear Lorentz signs check; mollification, shell estimates and test-source injectivity give equality almost everywhere. |
| Directivity and causality | §9, pp. 10–11 | Directivity inequality follows from the optical theorem; scalar Lorentz parameters attain \(a+ib\) at one selected frequency. No bandwidth or common-resource guarantee follows or is claimed. |

No essential proof step appears to have been lost by consolidation. The 15-page manuscript supplies its analytic foundations and both tuning arguments. P2-01 is a definite notation/domain repair, not evidence that a new theorem is needed. The scalar thickness law, quartic small-object results and fixed-resource bounds are not prerequisites for Paper 1; retain the intended Paper 2/Paper 3 separation.

### Lean correspondence: separate the five categories

| Category | Evidence and assessment |
|---|---|
| Kernel-verified encoded propositions | The archived final manifest reports the complete project build, 5,654 project constants, foundation axioms propext/Classical.choice/Quot.sound, and a fresh aggregate replay using the same Lean kernel. This pass inspected those records and the source, rather than performing a new full replay. |
| Main-statement semantic correspondence | PhysicalTheorem11.lean:12–29 explicitly includes existence, both prescribed-target suprema, all-state almost-everywhere uniqueness, full optical certificates, reciprocity, universal bounds and strictness. Basic.lean:34–39 and 53–77, Maxwell.lean:50 and 75–81, and PrescribedExtinctionClass.lean:9–27 match the paper's material bounds, two-layer square geometry, smooth weak tests, specified incident pair, and physical state class. No principal mismatch was found. |
| Independent archived semantic audit | Located only for 5a8350d, with incompleteness findings at that stage. A separate later all-PASS report for 686402a was not located. This audit's current source inspection does not create that missing historical evidence. |
| Exposition not individually formalized | The numerical Green-volume bound, Weyl-fiber proof organization, Appendix B amplitude vectors, explicit root scaling, causal oscillator observation and directivity consequence are correctly treated by the correspondence table as exposition, consequences, or differently organized proofs. They are not all individually kernel-certified formulas. |
| Physical model and priority | One-frequency, local, reciprocal, anisotropic, nonmagnetic dielectric tensors; unbounded resources across the sequence; no common loss floor or bandwidth constraint. Neither Lean checking nor this source comparison establishes experimental realization, journal eligibility, or first priority. |

FullPrescribedSuprema.lean:32–58 proves nonemptiness and genuine least-upper-bound statements; the suprema are not obtained by relying on a default value for empty or unbounded sets. FullPhysicalOpticalTheorem.lean:13–26 includes actual forward work, full sphere-area scattering, flux limit, and uniform far-field remainder. The completed source resolves the old F1–F4 obligations at the proposition level; it does not retrospectively change the scope of the old independent report.

### Literature and priority findings

The existing 17 bibliography entries were checked against primary publisher, author-preprint, or institutional records. No fabricated entry or DOI/title mismatch was found. Claim support was checked to the level available; inaccessible full equations were not treated as proof of non-equivalence.

- [Sounas–Alù 2014](https://www.wip.osapublishing.org/ol/abstract.cfm?uri=ol-39-13-4053) and [Hopkins 2015](https://www.mdpi.com/2304-6732/2/2/745) support reciprocal extinction equality and directional absorption/scattering; [Armitage 2014](https://arxiv.org/pdf/1311.5556) supplies the stated Jones/polarizer-waveplate precedent. [Ra'di 2013](https://arxiv.org/abs/1211.3549) distinguishes reciprocal from nonreciprocal bianisotropic classes, and [Sounas–Alù 2017](https://link.aps.org/accepted/10.1103/PhysRevLett.118.154302) has the different lossless hypotheses stated in the manuscript.
- [Andersen–Frandsen 2005](https://vbn.aau.dk/ws/files/19704710/Absorption_Efficiency.pdf) and [Schab 2020](https://arxiv.org/abs/2009.08502) support the efficiency/directivity and fixed-material/resource context. [Khurgin–Sun 2011](https://arxiv.org/abs/1110.0753) is genuine loss-scaling context; P1-02 supplies the more relevant mechanism citation.
- [Kononchuk 2019](https://journals.aps.org/prapplied/abstract/10.1103/PhysRevApplied.12.054046) uses magnetic Faraday rotation in the complete device. [Máñez-Espina 2026](https://onlinelibrary.wiley.com/doi/full/10.1002/nap2.70145) is a genuine reciprocal metasurface model with full-wave comparisons. Those comparisons should retain their constitutive and normalization qualifications.
- [Gao 2013](https://www.sciencedirect.com/science/article/pii/S0022407313001064) is a genuine polarized-extinction plate paper; its full equation-level equivalence was not certified here. [Bruno 2016](https://arxiv.org/abs/1507.04445) and [Arrieta 2022](https://research.utwente.nl/en/publications/windowed-green-function-mom-for-second-kind-surface-integral-equa/) concern windowed layered-background integral equations; [Yurkin–Mishchenko 2018](https://www.scattering.ru/papers/Yurkin%20and%20Mishchenko%20-%202018%20-%20Volume%20integral%20equation%20for%20electromagnetic%20scatt.pdf) and [Mishchenko–Yurkin 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6074055/) support VIE/radiation infrastructure. Those citations are context, not a substitute for the present anisotropic proof.
- **Mann–Alù 2023 remains an unresolved priority comparison, not a correction ticket against the current cautious text.** The [official conference program](https://congress2023.metamorphose-vi.org/index.php/component/svisor/?Itemid=156&task=showScheduleSvisor) verifies the authors, title, 14 September 2023 presentation, and qualitative directional-absorption abstract. Full equations and exact theorem equivalence were not verified. Retain main.tex:50's caveat. Do not invent a DOI or infer \(\Gamma=1\) merely from maximal dipolar absorption.

### Rendering findings

All 15 existing full-page PDF renders and 16 HTML screenshots were visually inspected. No missing glyph, equation-number collision, unrecoverable clipping, or incorrect theorem numbering was found. Independent structural checks found all 73 HTML internal links resolved, no duplicate IDs, and all 51 equation numbers matching LaTeX labels. The PDF's 59 internal link annotations resolved against its named destinations. Website availability was not established by those internal-link checks.

The PDF is visually sound in the existing layout. Missing authorship is visibly confirmed. Mobile equations intentionally use local horizontal scrolling; P3-02 improves its discoverability. Compilation or layout success alone does not establish publication readiness.

## Final correction summary

### 1. Readiness for external professor review

The corrected manuscript and linked local supplements are ready for external professor review as a draft. Theorems 4.1 and 7.1 and their hypotheses remain unchanged. The global/restricted Fourier ambiguity is repaired. The regenerated PDF is 16 pages: the vector schematic and necessary clarifications account for the additional space; the 11-point type and one-inch margins were retained.

This is not approval for journal submission. Authorship and factual declarations remain for explicit human approval. The reportedly later final-commit audit was not available for verification.

### 2. Ticket accounting

| Baseline priority | Tickets | Resolved for this review package | Unresolved | Requiring human approval |
|---|---:|---:|---:|---:|
| P0 | 0 | 0 | 0 | 0 |
| P1 | 7 | 3 | 1 | 3 |
| P2 | 5 | 5 | 0 | 0 |
| P3 | 2 | 2 | 0 | 0 |
| Total | 14 | 10 | 1 | 3 |

P1-06 is resolved for access to the accompanying review package, not as a claim of public archival deposition. P2-04 is resolved by a restrained citation, not a completed equation-level equivalence audit.

### 3. Principal completed corrections

1. Repaired Eq. (35)'s observation domain and rechecked the uniform aperture argument.
2. Added verified Khurgin 2021, Gustafsson 2012 and Yazdi 2015 references; preserved Mann–Alù uncertainty.
3. Replaced private drafting language with scientific exposition and identified local S1–S4 supplements.
4. Clarified slab/stack reference planes, phases and vacuum subtraction.
5. Added an accurate vector construction figure and accessible mobile equation scrolling.

### 4. Main theorem and aperture preservation

Theorem 4.1 and Theorem 7.1 are byte-identical to the baseline source. Section 8 and Appendix A are unchanged. Of 51 numbered equations, only Eq. (35) changed, by replacing the Fourier transform of H with that of the global auxiliary H-tilde. No bound, sign, material hypothesis, supremum, target or tuning argument changed. See [mathematical consistency report](MATHEMATICAL_CONSISTENCY.md).

### 5. Verification claims

Section 10 identifies the completed encoded theorem and the archived kernel evidence. The export manifest's independent-review status is explicitly dated. Independent AI semantic audit, Lean kernel checking and human scientific review remain distinct. Expanded searches found the baseline audit of 5a8350d, not a substantive final-commit all-PASS report. See [S4 audit provenance](reproducibility/AUDIT_PROVENANCE.md). A successful current format build does not settle the missing historical report or priority.

### 6. Potential missing proof steps

No new substantive mathematical issue was identified. The corrected mixed estimates reserve global L2 for low frequencies and use transverse Linfinity control before restriction for the grazing/high-frequency part. Both exact-target IVTs retain the original order of parameter choices. No Paper 2 quartic/fixed-resource or Paper 3 thickness result was imported.

### 7. Independent review still warranted

External human Maxwell-analysis review is the intended next step, particularly for localization, the weak Maxwell model and source-level correspondence. This correction review is AI-assisted and is not human certification. Obtain and evaluate the reportedly existing later audit before claiming its PASS verdicts or commissioning duplicate work.

### 8. Remaining correction/submission order

1. Locate and assess the actual final-commit audit, if it exists.
2. Obtain approved authorship/contact and factual funding/conflict/acknowledgment/assistance declarations.
3. Choose the target venue and resolve its actual policy compatibility, including any generated-text restriction.
4. Approve public supplement/archive access or venue-specific deposition; do not invent a DOI or availability-on-request promise.
5. Incorporate professor feedback, regenerate both formats and recheck the source invariants before any separately authorized release.

### 9. Completed generation checklist

- [x] Theorems 4.1 and 7.1 and all material/target quantifiers unchanged.
- [x] Global auxiliary Fourier definition, restricted residual and both frequency estimates checked.
- [x] Boundary-plane conventions, both cascade directions and vacuum/zero-loss limits checked.
- [x] Three new citations added; Mann–Alù caveat retained.
- [x] S1–S4 and actual local supplement index linked; original frozen artifacts hash-verified.
- [x] PDF/HTML regenerated from the same LaTeX and BibTeX; 51 equations, 20 references and one figure.
- [x] All 417 MathML TeX annotations match a fresh parse of the authoritative LaTeX, in order.
- [x] Figure PDF/SVG use the same vector drawing specification; HTML embeds the exact SVG bytes.
- [x] No TeX layout/citation warning, missing HTML anchor, duplicate ID or MathML error.
- [x] 1440-px and 390-px rendering, figure loading and mobile keyboard/full-equation access checked.
- [x] All 378 frozen library source hashes and original input hashes matched; Git HEAD and clean status preserved.
- [ ] Human scientific review and authorship/declaration approval.
- [ ] Final independent audit evidence reconciliation and venue/public-availability decisions.

Detailed fresh checks are recorded in [validation](review/validation.json); the original audit baseline is preserved in review/pre-correction/.

### 10. Items still blocking journal submission

- **P1-01:** The actual later final-commit independent audit is unavailable. No final independent PASS claim can be added. This does not invalidate the frozen kernel certificates or prevent professor review.
- **P1-04:** Human authorship, affiliations, order and corresponding contact must be approved.
- **P1-05:** Funding, conflicts and applicable acknowledgments must be confirmed and inserted.
- **P1-07:** Target venue and truthful assistance account must be approved. Optica's generated-text policy poses a conditional compatibility issue; an acknowledgment alone may not resolve it.
- **P1-06 release follow-up:** Approve actual public or journal-hosted supplement access and update links for the eventual destination. Current links identify a local review package.

The full Mann–Alù 2023 equations and detailed Yazdi 2015 comparison remain scholarly-access questions. No first-priority or exact-equivalence claim has been added. They should be addressed before making stronger novelty assertions.
