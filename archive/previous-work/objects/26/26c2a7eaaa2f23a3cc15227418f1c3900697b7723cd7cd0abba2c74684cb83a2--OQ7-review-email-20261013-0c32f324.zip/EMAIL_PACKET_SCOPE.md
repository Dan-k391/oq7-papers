# Email review packet scope

This packet includes the review PDF/source, S1–S4, exact frozen Lean source archive/Git bundle, portable release source archive, current type/axiom/auditor/fresh-replay logs, completed audit reports and programs, ordinary review, historical version map and the existing targeted priority report.

It omits the 850 MB pinned Windows compiler, all nine dependency source/Git snapshots, redundant release/manuscript/ copies, PDF-render PNGs, redundant release/frozen/ source archive/bundle copies and the portable Git bundle. The same exact audited source/Git bundle remain in supplements/ and manuscript/reproducibility/. The portable source remains in release/portable-source.zip.

All omitted items are included in the complete local source-and-audit archive. The main REPRODUCE.md and RELEASE_INDEX.md describe that complete package. Links to omitted snapshot files require the complete archive. This packet's SHA256SUMS covers its own included members only.

No human peer review, independent-kernel checker or established first priority is claimed. This is an anonymous review copy, not a named journal submission.
