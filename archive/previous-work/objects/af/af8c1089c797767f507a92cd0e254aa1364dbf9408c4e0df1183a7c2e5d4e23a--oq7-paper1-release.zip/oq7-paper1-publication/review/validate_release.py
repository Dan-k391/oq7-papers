"""Verify format inventories, source preservation, and final release integrity."""
from pathlib import Path
import csv
import hashlib
import json
import re
import subprocess
from lxml import html as lhtml
import pdfplumber
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent/"oq7-prescribed-extinction"
errors=[]
def require(condition,message):
    if not condition: errors.append(message)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

formats=json.loads((ROOT/"build/format-correspondence.json").read_text(encoding="utf-8"))
for name,sha in formats["source_sha256"].items():
    require(digest(ROOT/name)==sha,"Rendered source is stale: "+name)
log=(ROOT/"build/main.log").read_text(encoding="utf-8",errors="replace")
tex_issues=re.findall(r"(?:Overfull|Underfull)[^\n]*|LaTeX Warning:[^\n]*|! [^\n]*",log)
require(not tex_issues,"Final TeX log contains layout/citation errors")
doc=lhtml.fromstring((ROOT/"paper.html").read_bytes())
ids=doc.xpath('//*[@id]/@id')
require(len(ids)==len(set(ids)),"Duplicate HTML IDs")
hrefs=doc.xpath('//a[starts-with(@href,"#")]/@href')
missing=[href[1:] for href in hrefs if href[1:] not in ids]
require(not missing,"Unresolved HTML references")
equations=doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," equation ")]')
require({e.get("id") for e in equations}==set(formats["equation_labels"]),"Equation labels differ")
require(len(doc.xpath('//math'))==formats["math_expressions"],"MathML expression inventory differs")
require(not doc.xpath('//merror'),"MathML errors")
require(len(doc.xpath('//ol[@class="references"]/li'))==formats["references"],"Reference count differs")
require(not doc.xpath('//script[@src] | //link[@rel="stylesheet"] | //img[@src]'),"HTML has remote/extra rendering dependencies")
aux=(ROOT/"build/main.aux").read_text(encoding="utf-8")
labels=dict(re.findall(r"\\newlabel\{([^}]+)\}\{\{([^}]+)\}",aux))
for e in equations:
    require(e.get("data-number")==labels[e.get("id")],"Equation number mismatch: "+e.get("id"))
headnums=re.findall(r"\\contentsline \{(?:section|subsection)\}\{\\numberline \{([^}]+)\}",aux)
heads=doc.xpath('//main/h2 | //main/h3')
require(len(heads)==len(headnums),"Numbered section inventory differs")
for heading,n in zip(heads,headnums):
    require(heading.text_content().startswith(n+" "),"Heading number mismatch: "+heading.text_content())
reader=PdfReader(ROOT/"paper.pdf")
pdftexts=[p.extract_text() for p in reader.pages]
require(all(t.strip() for t in pdftexts),"Empty PDF page")
require(all("\ufffd" not in t for t in pdftexts),"Replacement glyph in PDF text")
require(len(reader.pages)==15,"Unexpected final page count")
pdftext="\n".join(pdftexts)
for i in range(1,formats["equations"]+1):
    require("("+str(i)+")" in pdftext,f"PDF equation {i} missing")
for i in range(1,formats["references"]+1):
    require("["+str(i)+"]" in pdftext,f"PDF reference {i} missing")
bounds=[]
with pdfplumber.open(ROOT/"paper.pdf") as pdf:
    for i,page in enumerate(pdf.pages):
        words=page.extract_words()
        bad=[w for w in words if w["x0"]<65 or w["x1"]>547 or w["top"]<55 or w["bottom"]>760]
        if bad: bounds.append(dict(page=i+1,words=[w["text"] for w in bad]))
require(not bounds,"PDF text outside checked page margins")
browser=json.loads((ROOT/"review/html-render-check.json").read_text(encoding="utf-8"))
for r in browser:
    require(r["documentWidth"]<=r["viewport"]+1,"Browser page overflow")
    require(r["mathErrors"]==0 and not r["missingLinks"] and not r["duplicateIds"],"Browser semantic/render errors")
    require(r["equations"]==51 and r["mathExpressions"]==389 and r["references"]==17,"Browser format inventory differs")
cert=json.loads((REPO/"verification/report.json").read_text(encoding="utf-8-sig"))
mismatches=[s["file"] for s in cert["sourceHashes"] if digest(REPO/s["file"]).lower()!=s["sha256"].lower()]
require(not mismatches,"Frozen source hashes changed")
status=subprocess.check_output(["git","status","--porcelain"],cwd=REPO,text=True)
commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=REPO,text=True).strip()
require(not status,"Frozen Git checkout modified")
require(commit=="686402a6c2d63820828729cc7ab02504632e3fe7","Frozen commit changed")
inputs=json.loads((ROOT/"review/input-manifest.json").read_text(encoding="utf-8"))
require(all(digest(Path(s["path"]))==s["sha256"] for s in inputs),"Original input changed")
copies=json.loads((ROOT/"reproducibility/copy-manifest.json").read_text(encoding="utf-8"))
require(all(digest(ROOT/"reproducibility"/s["name"])==s["sha256"] for s in copies),"Copied frozen artifact changed")
with (ROOT/"theorem-correspondence.csv").open(encoding="utf-8-sig",newline="") as f:
    rows=list(csv.DictReader(f))
require(len(rows)==52,"Correspondence row inventory changed")
for row in rows:
    require(row["manuscript_number"]==labels.get(row["manuscript_label"],""),"Stale correspondence numbering")
checks=(ROOT/"review/correspondence-lean-check.log").read_text(encoding="utf-8-sig")
require("error:" not in checks.lower(),"Correspondence Lean check failed")
for row in rows:
    for name in row["lean_declarations"].split("; ") if row["lean_declarations"] else []:
        require(name in checks,"Correspondence declaration missing from current log: "+name)
output=dict(passed=not errors,errors=errors,pdf_pages=len(reader.pages),pdf_layout_log_issues=tex_issues,
            pdf_word_bounds_issues=bounds,html_viewports=[r["width"] for r in browser],
            equations=51,math_expressions=389,references=17,correspondence_rows=len(rows),
            matched_library_hashes=len(cert["sourceHashes"]),frozen_commit=commit,original_checkout_unchanged=not status,
            source_hash_mismatches=mismatches,current_declaration_check_exit=0,current_correspondence_check_exit=0,
            current_fresh_same_kernel_replay_exit=0,
            kernel_replay_scope="Entire PrescribedExtinction aggregate import closure; same Lean kernel implementation",
            independent_semantic_review="Pending for completed frozen commit",
            independent_kernel_implementation_used=False,
            manuscript_source_sha256=formats["source_sha256"],
            output_sha256={n:digest(ROOT/n) for n in ["paper.pdf","paper.html","theorem-correspondence.csv"]},
            visual_qa="All pages rendered; contact sheet and key full-size PDF pages and desktop/mobile formula/reference screenshots reviewed separately")
(ROOT/"review/validation.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
print(json.dumps(output,indent=2))
if errors: raise SystemExit(1)
