# OQ7 Paper 1 publication package

This is a consolidated research manuscript for expert review. It has not been submitted or publicly published. Human confirmation of authorship, affiliations, acknowledgments, disclosure wording, and unresolved priority comparisons remains necessary.

The primary scientific source is the 11 October 2026 prescribed-extinction manuscript. The frozen Lean source is commit `686402a6c2d63820828729cc7ab02504632e3fe7`. The original repository and all original PDFs were preserved. This package is a separate sibling directory.

## Files

- `main.tex`: authoritative editable scientific text and equations.
- `references.bib`: authoritative bibliography; 17 cited primary publications/contributions.
- `main.bbl`: BibTeX output supplied for an arXiv source upload.
- `paper.pdf`: typeset research manuscript.
- `paper.html`: responsive offline HTML, using native MathML.
- `build.py`, `template.html`: reproducible PDF/HTML generation.
- `theorem-correspondence.csv`, `theorem-correspondence.html`: detailed statement-to-Lean mapping, with qualifications for auxiliary exposition.
- `outstanding-issues.txt`: remaining scientific and publication review.
- `source-provenance.txt`, `review/input-manifest.json`: source roles, incorporation decisions, and hashes.
- `reproducibility/`: byte-identical frozen source archive, Git bundle, and original manifest/prompt.
- `review/PublicationCheck.lean`, `review/publication-lean-check.log`: current exact declaration/type/assumption exports.
- `review/publication-fresh-kernel.log`: current empty-environment aggregate replay.
- `review/publication-source-check.json`, `review/lean-source-inventory.json`: frozen source identity and all 378 current library files.
- `build/format-correspondence.json`, `review/html-render-check.json`, `review/validation.json`: format inventories and checks.

No scientific figure is required by this analytic argument. The older diagnostic plots and numerical tables were not incorporated because their scripts and original editable figure sources were unavailable, and they are not proof dependencies. No newly invented numerical evidence is included.

## Compile the manuscript

For a conventional TeX Live or MiKTeX installation with `latexmk` and BibTeX:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The project uses the standard `article` class, Latin Modern fonts, AMS mathematics/theorem packages, geometry, microtype, graphicx, booktabs, natbib, and hyperref. It does not require shell escape or external scientific assets. Upload `main.tex`, `references.bib`, and the matching `main.bbl` to arXiv only after human review; no upload was performed.

The build used Tectonic 0.17.0 and Pandoc 3.12.1. Official Windows portable binaries were downloaded into the local `tools/` directory; their SHA-256 values match GitHub's release asset digests, recorded in `tools/tool-download-manifest.json`. The binaries are retained locally and omitted from the distributable ZIP; install those tool versions to rebuild an extracted ZIP package. Tectonic may need network access for its standard TeX bundle on the first compile. This does not make the delivered HTML depend on network access.

To reproduce both delivered formats, install Python 3 and those tool versions, or use the local portable tools:

```sh
python build.py --tectonic /path/to/tectonic --pandoc /path/to/pandoc
```

With the bundled Windows executables, `python build.py` discovers their paths. If only the PDF/HTML conversion is needed after a successful compile in `build/`:

```sh
python build.py --skip-pdf --pandoc /path/to/pandoc
```

The HTML converter reads the same LaTeX with Pandoc, expands its macros, resolves all labels and citation numbers from `build/main.aux`, and renders the BibTeX-generated `build/main.bbl`. It does not maintain a separate scientific text. The HTML contains all 51 numbered equations, six numbered theorem/lemma/proposition environments, and 17 references. It uses native MathML and no remote fonts, CDN, or JavaScript math loader. Long phone-width formulas scroll within their own containers.

## Reproduce the Lean project without changing the frozen checkout

The reviewed baseline audit concerns `5a8350d5408c38e333c9f6b6d8a94816c794120b`. The supplied frozen manifest explicitly says independent semantic review of the completed commit is still pending. Do not describe the baseline audit as an independent audit of `686402a6...`.

Use a new disposable directory. The Git bundle preserves history and the exact frozen commit:

```sh
git clone reproducibility/OQ7-complete-physical-theorem11.bundle oq7-replay
cd oq7-replay
git checkout --detach 686402a6c2d63820828729cc7ab02504632e3fe7
```

Alternatively, extract `OQ7-complete-physical-theorem11-source.zip` into a new directory. Do not extract over the original repository. The archive includes preserved source references and certificate logs.

Pins: Lean 4.34.1, compiler commit `5045d0056413266e57c625dcd7c365b10e377c52`; Mathlib `d13f23b723b8a846827a245b89c10fc7d3f11612`. The original `sources/pinned-lake-manifest.json` records every transitive dependency revision. Do not upgrade the pins.

The original `lakefile.toml` points at a Windows package cache. In the disposable checkout only, run:

```sh
python configure.py
lake resolve-deps
lake build OQ7 PrescribedExtinction
lake env leanchecker --fresh --verbose PrescribedExtinction
```

`configure.py` replaces the package path and restores the pinned manifest; it is a documented build-configuration change, not a modification of the theorem. To reuse a clean cache at the exact revisions, pass `--packages-directory /absolute/path/to/.lake/packages`. For a complete dependency-from-source audit, decline/remove dependency build caches in the disposable checkout as appropriate and build from the pinned source revisions. The original verifier's `-Clean` option cleans the project; it does not establish a dependency-from-source rebuild of a shared cache.

With PowerShell and the pinned Lean `bin` directory on PATH:

```powershell
./verify.ps1 -Clean -BuildThreads 2
./verify-milestones.ps1 -Only obligation-1-universal-passivity,outgoing-weak-uniqueness,obligation-3-full-physical-optics,obligation-4-universal-nonattainment,obligation-5-complete-physical-theorem
./verify-kernel.ps1
```

The scripts write evidence in the disposable checkout. `LEAN_NUM_THREADS=2` was used for the current publication check. To repeat the exact publication exports, run `lake env lean /absolute/path/to/review/PublicationCheck.lean` from the configured disposable checkout.

The fresh replay uses the same Lean kernel implementation, starting from an empty environment. It is different from a clean source build and from an independently implemented proof checker. The new publication pass checked the principal declaration and selected major dependencies, matched all 378 frozen source hashes, and successfully replayed the entire `PrescribedExtinction` aggregate. It did not redo the historical dependency-from-source build or independent human semantic review.

## Review scope

The main existence statement and complete physical theorem correspond to the two-layer square-aperture class, fixed real linear polarization, local reciprocal permittivity, nonmagnetic vacuum background, strictly positive per-object tensor loss, and the prescribed positive extinction. Some auxiliary exposition (the displayed volume-only numerical Green bound, exact inverse-angle root scaling, Weyl-fiber proof organization, and causal oscillator compatibility) is ordinary mathematics carried over from the source manuscripts and is not separately certified as an identically phrased Lean declaration. The correspondence table identifies these distinctions.

The outstanding-issues file is part of the package. An expert should review semantic fidelity, the weak-field argument, the zero-angle planar formulas, the physical-aperture passage, and unresolved literature equivalence before calling the manuscript submission-ready.
