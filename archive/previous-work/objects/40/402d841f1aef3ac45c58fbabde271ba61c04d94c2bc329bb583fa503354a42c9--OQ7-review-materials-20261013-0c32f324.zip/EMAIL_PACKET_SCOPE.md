# Email review packet scope

This packet includes the review PDF/source, S1–S4, frozen Lean source/Git bundle, portable release source, current type/axiom/auditor/fresh-replay logs, completed audit reports, ordinary review, historical version map and the existing targeted priority report.

It omits the 850 MB pinned Windows compiler, the nine dependency source/Git snapshots, redundant release/manuscript/ copies and PDF-render PNGs. These are included in the complete local source-and-audit archive. The main REPRODUCE.md and RELEASE_INDEX.md describe that complete package. Links to omitted snapshot files require the complete archive. This packet's SHA256SUMS covers its own included members only.

No human peer review, independent-kernel checker or established first priority is claimed. This is an anonymous review copy, not a named journal submission.
